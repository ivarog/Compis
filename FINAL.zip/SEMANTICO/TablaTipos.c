/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
    29/11/18 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "TablaTipos.h"

//Se crea un nuevo nodo, es utilizado por la función insertar
NODOTABLA *CrearNodoTablaTipos(long hash, int tipo, int tamano, int tipoBase)
{
    NODOTABLA *nuevo = NULL;
    nuevo = (NODOTABLA *)malloc(sizeof(NODOTABLA));
    if (nuevo != NULL)
    {
        nuevo->position = hash;
        nuevo->tipo = tipo;
        nuevo->tam = tamano;
        nuevo->tipoBase = tipoBase;
        nuevo->siguiente = NULL;
        nuevo->anterior = NULL;
    }
    return nuevo;
}

//Se inserta un elemento al inicio de la lista
int InsertarInicioTablaTipos(NODOTABLA **cabeza, long hash, int tipo, int tamano, int tipoBase)
{
    NODOTABLA *nuevo = NULL;
    nuevo = CrearNodoTablaTipos(hash, tipo, tamano, tipoBase);
    if (nuevo != NULL)
    {
        nuevo->siguiente = *cabeza;
        nuevo->anterior = NULL;
        if (*cabeza != NULL)
        {
            (*cabeza)->anterior = nuevo;
        }
        *cabeza = nuevo;
        return 1;
    }
    return 0;
}

//Se inserta un elemento al final de la lista
int InsertarFinalTablaTipos(NODOTABLA **cabeza, long hash, int tipo, int tamano, int tipoBase)
{
    NODOTABLA *nuevo = NULL, *nAux = *cabeza;
    nuevo = CrearNodoTablaTipos(hash, hash, tamano, tipoBase);
    if (nuevo != NULL)
    {
        while (nAux->siguiente != NULL)
        {
            nAux = nAux->siguiente;
        }
        nuevo->anterior = nAux;
        nAux->siguiente = nuevo;
        return 1;
    }
    return 0;
}

//Imprime la fila de la tabla 
void imprimirFilaTabla(NODOTABLA *cabeza)
{
    NODOTABLA *nAux = cabeza;
    while (nAux != NULL)
    {
        printf("%ld\t\t", cabeza->position);
        printf(" %d\t", cabeza->tam);
        printf(" %d\t", cabeza->tipo);
        printf(" %d\t", cabeza->tipoBase);
        printf("\n");
        nAux = nAux->siguiente;
    }
}

//Imprime la tabla completa
void imprimirTablaTipos(tablaTipos *tabla){
    int cuenta = tabla->cuenta;
    printf("Tabla Tipos\n");
    printf("id tabla %d\n", tabla->id);
    printf("posicion \t tam \t tipo \t tipoBase\n");
    int i;
    for (i = 0; i < cuenta; i++)
    {
        int j = tabla->posiciones[i];
        imprimirFilaTabla(tabla->nodos[j]);
    }
}

//obtiene la llave solicitada de la tabla
long getKeyTablaTipos(int tipo, int tam, int tipoBase)
{
    if (tipoBase > -1)
    {
        return tipo * pow(31, 2) + tam * 31 + tipoBase;
    }
    return tipo * pow(31, 2) + tam * 31;
}

int iguales(NODOTABLA *fila, int tipo, int tam, int tipoBase){
    
    if( (fila->tam == tam) && (fila->tipo == tipo) && (fila->tipoBase == tipoBase)){
        return 1;
    }
    return 0;
}

//Inserta una nueva fila en la tabla tipos
int insertarFilaTablaTipos(tablaTipos **tabla, int tipo, int tam, int tipoBase)
{
    long numeroPrimo = 263;
    long hash = getKeyTablaTipos(tipo, tam, tipoBase) % numeroPrimo;
    //printf("posicion en la tabla %ld\n", hash);
    if ((*tabla)->nodos[hash] == NULL) {
        insertarPosiciones(&((*tabla)->posiciones), hash, &((*tabla)->cuenta));
        InsertarInicioTablaTipos(&((*tabla)->nodos[hash]), hash, tipo, tam, tipoBase);
    }
    else {
        
        //printf("posicion ya ocupada\n");
        if (iguales((*tabla)->nodos[hash], tipo, tam, tipoBase) != 0) {
            return hash;
        }
        InsertarInicioTablaTipos(&((*tabla)->nodos[hash]), hash, tipo, tam, tipoBase);
    }
    return hash;
}
