/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
    2/12/18*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtab.h"
#include "attributes.h"
#include "backpatch.h"
#include "intermediate_code.h"

extern FILE* yyin;
extern int yyparse();

/*Función para abrir un archivo de entrada y utilizarlo en yyparse
 */
int main(int argc, char** argv) {
    FILE *f;

    if(argc<2) return -1;
    f=fopen(argv[1],"r");
    yyin=f;
    yyparse();
    fclose(f);
    return 0;
    /*printf("abriendo el archivo\n");
    yyin = fopen("prueba","r");
    //printf("abriendo el archivo\n");
    yyparse();
    fclose(yyin);
    return (EXIT_SUCCESS);*/
}

