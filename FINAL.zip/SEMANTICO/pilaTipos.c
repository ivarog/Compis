/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
    26/11/18*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pilaTipos.h"

//Función encargada de agregar un elemento a la pila
void pushTipos(struct elementoTipos **cabeza, struct elementoTipos *nuevo)
{
    //Pila vacia
    if ((*cabeza) == NULL)
    {
        (*cabeza) = nuevo;
    }
    else
    {
        nuevo->siguiente = (*cabeza);
        (*cabeza) = nuevo;
    }
    //imprimirPila(*cabeza);
}

//Función encargada de obtener el elemento en la cima de la pila
struct elementoTipos *popTipos(struct elementoTipos **cabeza) {
    if (*(cabeza) == NULL)
    {
        return NULL;
    }
    struct elementoTipos *elemento_retorno = *(cabeza);
    *(cabeza) = elemento_retorno->siguiente;
    return elemento_retorno;
}