#ifndef TABLA_SIMBOLOS
#define TABLA_SIMBOLOS
#include "listaArgs.h"

typedef struct filaTablaSimbolos{
    int position;
    char* id;
    int tipo;
    int dir;
    int var;
    NODO* args;
    int ocupado;
} fila;

typedef struct TablaSimbolos{
    int cuenta;
    int *posiciones;
    int id;
    fila filas[467];
} tablaSimbolos;

void imprimirTablaSimbolos(tablaSimbolos *tabla);
int getKey(char* id);
int insertarFila(tablaSimbolos **tabla,char* id, int tipo, int dir, int var, NODO *args);
int existe(tablaSimbolos *tabla, char* id);

#endif