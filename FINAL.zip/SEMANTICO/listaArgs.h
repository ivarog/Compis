#ifndef LISTA_ARGS
#define LISTA_ARGS
//Estructura que define el contenido de cada nodo de la lista
typedef struct nodo
{
    int dato;
    struct nodo *siguiente;
    struct nodo *anterior;
}NODO;

NODO *CrearNodo(int dato);

NODO *CrearNodo(int dato);

int InsertarInicio(NODO **cabeza, int dato);

int InsertarFinal(NODO **cabeza, int dato);

int EliminarNodo(NODO **cabeza, int dato);

void imprimirLista(NODO *cabeza);

void insertarPosiciones(int **posiciones, int hash, int *cuenta);

#endif