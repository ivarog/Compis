/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
    26/11/18*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "pilaTablas.h"

//Función encargada de agregar un elemento a la pila
void push(struct elemento** cabeza,struct elemento* nuevo)
{
    //Pila vacia
    if((*cabeza)==NULL)
    {
        (*cabeza)=nuevo;
    }
    else
    {
        nuevo->siguiente= (*cabeza);
        (*cabeza) = nuevo;
    }
    //imprimirPila(*cabeza);
}

//Función encargada de obtener el elemento en la cima de la pila
struct elemento* pop(struct elemento** cabeza)
{
    if(*(cabeza)==NULL)
    {
        return NULL;
    }
    struct elemento* elemento_retorno=*(cabeza);
    *(cabeza)=elemento_retorno->siguiente;
    return elemento_retorno;
}
//
////Función encargada en imprimir los elementos de la pila
void imprimirPila(struct elemento *cabeza){
    printf("Imprimir pila\n");
    struct elemento* tmp = cabeza;
    while(tmp != NULL){
        //printf("NODO %p\n", tmp);
        //printf("%p\n", tmp->siguiente);
        printf("HOLA direccion de la tabla apuntada %d\n",(*(tmp->tabla))->id);
        //imprimirTablaSimbolos(*(tmp->tabla));
        tmp = tmp->siguiente;
    }
}
//
//void crearPila(struct elemento **pila) {
//    (*pila) =(struct elemento*)malloc(sizeof(struct elemento));
//}
//
//struct elemento* ultimoElemento(){
//    return ultimo;
//}
//
//void main(){
//    struct elemento* pilaTablas1 = NULL;
//    struct elemento *tmp1 = (struct elemento *)malloc(sizeof(struct elemento));
//    push(&pilaTablas1, tmp1);
//    push(&pilaTablas1, (struct elemento *)malloc(sizeof(struct elemento)));
//    push(&pilaTablas1, (struct elemento *)malloc(sizeof(struct elemento)));
//    push(&pilaTablas1, (struct elemento *)malloc(sizeof(struct elemento)));
//    push(&pilaTablas1, (struct elemento *)malloc(sizeof(struct elemento)));
//    imprimirPila(pilaTablas1);
//}