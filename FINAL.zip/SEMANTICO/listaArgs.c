/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
    28/11/18*/
#include<stdio.h>
#include<stdlib.h>
#include "listaArgs.h"

//Se crea un nuevo nodo, es utilizado por la función insertar
NODO *CrearNodo(int dato)
{
    NODO* nuevo=NULL;
    nuevo=(NODO*)malloc(sizeof(NODO));
    if(nuevo!=NULL)
    {
        nuevo->dato=dato;
        nuevo->siguiente=NULL;
        nuevo->anterior=NULL;
    }
    return nuevo;
}

//Se inserta un elemento al inicio de la lista
int InsertarInicio(NODO **cabeza, int dato)
{
    NODO* nuevo=NULL;
    nuevo=CrearNodo(dato);
    if(nuevo!=NULL)
    {
        nuevo->siguiente=*cabeza;
        nuevo->anterior=NULL;
        if(*cabeza!=NULL)
        {
            (*cabeza)->anterior=nuevo;
        }
        *cabeza=nuevo;
        return 1;
    }
    return 0;
}

//Se inserta un elemento al final de la lista
int InsertarFinal(NODO **cabeza, int dato)
{
    NODO* nuevo=NULL, *nAux=*cabeza;
    nuevo=CrearNodo(dato);
    if(nuevo!=NULL)
    {
        while(nAux->siguiente!=NULL)
        {
            nAux=nAux->siguiente;
        }
        nuevo->anterior=nAux;
        nAux->siguiente=nuevo;
        return 1;
    }
    return 0;
}
//Se elimina el primer nodo que contenga el dato pasado por parámetro
int EliminarNodo(NODO **cabeza, int dato)
{
    NODO *actual=*cabeza, *anterior=NULL, *siguiente=NULL;
    while(actual!=NULL)
    {
        if(actual->dato==dato)
        {
            if(actual==*cabeza)
            {
                *cabeza=actual->siguiente;
                if(actual->siguiente != NULL)
                {
                    actual->siguiente->anterior=NULL;
                }
            }
            else if(actual->siguiente==NULL)
            {
                anterior=actual->anterior;
                actual->anterior=NULL;
                anterior->siguiente=NULL;
            }
            else
            {
                anterior=actual->anterior;
                actual->anterior=NULL;
                siguiente=actual->siguiente;
                actual->siguiente=NULL;
                anterior->siguiente=siguiente;
                siguiente->anterior=anterior;
            }
            free(actual);
            return 1;
        }
        actual=actual->siguiente;
    }
    return 0;
}

//Imprime la lista
void imprimirLista(NODO *cabeza)
{
    NODO *nAux=cabeza;
    while(nAux!=NULL)
    {
        printf("%d \t",nAux->dato);
        nAux=nAux->siguiente;
    }
}

void insertarPosiciones(int **posiciones, int hash, int *cuenta){
    if(*posiciones == NULL){
        *posiciones = (int *)malloc(sizeof(int));
    }else {
        *posiciones = (int *)realloc(*posiciones, sizeof(int)*(*cuenta+1));
    }
    *((*posiciones) + *cuenta) = hash;
    *cuenta = *cuenta + 1;
}

/*int main()
{
    NODO *cabeza=NULL;
    InsertarInicio(&cabeza,1);
    InsertarInicio(&cabeza,2);
    InsertarInicio(&cabeza,3);
    InsertarInicio(&cabeza,2);
    InsertarInicio(&cabeza,4);
    InsertarInicio(&cabeza,5);
    InsertarInicio(&cabeza,6);
    InsertarInicio(&cabeza,7);
    InsertarFinal(&cabeza,23);
    imprimirLista(cabeza);
    EliminarNodo(&cabeza,2);    
    imprimirLista(cabeza);
    EliminarNodo(&cabeza,7);
    imprimirLista(cabeza);
    EliminarNodo(&cabeza,23);
    imprimirLista(cabeza);
    return 0;
}*/