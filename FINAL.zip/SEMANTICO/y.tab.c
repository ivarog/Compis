#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.8 (Berkeley) 01/20/90";
#endif
#define YYBYACC 1
#line 2 "semantic.y"
/* 
 * File:   semantic.y
 * Author: Adrian Ulises Mercado Martínez
 *
 * Created on 3 de diciembre de 2018, 19:36
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "attributes.h"
#include "symtab.h"
#include "backpatch.h"
#include "intermediate_code.h"
#include "TablaSimbolos.h"
#include "TablaTipos.h"
#include "pilaTablas.h"
#include "pilaTipos.h"
#define VAR 1
#define FUNCVAR 2


extern int yylex();
extern int yylineno;

/* Funciones para el manejo de errores */
void yyerror2(char*, char*);
void yyerror(char *);

/* Variable para el conteo de direcciones */
int dir=0;

/*variable para error ID*/
int errorIDLinea;

/* Variables para guardar el tipo y ancho actual */
int current_type;
int current_dim;

/* Varaibles para contar las temporales, etiquetas e indices */
int label;
int temp;
int indice;

/* Variable para el unico atributo heredado de sentencia prima*/
labels lfalses;


/* Variable para la tabla de símbolos*/
symtab tabla_de_simbolos;
tablaSimbolos *tablaSimbolos1;
tablaTipos *tablaTipos1;
int cuentaTablasSimbolos;
int cuentaTablasTipos;

/*variable de pila de Tablas*/
struct elemento *pilaTablas1 = NULL;
struct elementoTipos *pilaTipos1 = NULL;

/* Variable papra guardar el código intermedio que se va generando */
ic codigo_intermedio;


/* Funciones auxiliares al análisis semántico y generación de código intermedio */
void init();
void finish();

exp suma(exp e1, exp e2);
exp resta(exp e1, exp e2);
exp multiplicacion(exp e1, exp e2);
exp division(exp e1, exp e2);
exp get_numero(numero);
exp identificador(char *);
exp asignacion(char *id, exp e);

/* Funciones auxiliares para la comprobación de tipos */
int max(int t1, int t2);
char *ampliar(char *dir, int t1, int t2);
char *reducir(char *dir, int t1, int t2);


/* Funciones para generar temporales, etiquetas e indices */
char *newTemp();
char *newLabel();
char *newIndex();

#line 90 "semantic.y"
typedef union{
    numero num;    
    char id[32];
    int base;
    exp expresion;
    type tipo;
    struct{
	labels falses;
	labels trues;
    }booleanos;
    labels siguientes;
    struct{
        labels siguientes;
        bool ifelse;
    }siguientesp;
    int rel;
} YYSTYPE;
#line 111 "y.tab.c"
#define INT 257
#define FLOAT 258
#define DOUBLE 259
#define CHAR 260
#define VOID 261
#define STRUCT 262
#define PUNTOYCOMA 263
#define ID 264
#define COMA 265
#define NUMERO 266
#define FUNC 267
#define IF 268
#define ELSE 269
#define WHILE 270
#define DO 271
#define FOR 272
#define RETURN 273
#define SWITCH 274
#define BREAK 275
#define PRINT 276
#define CASE 277
#define DEFAULT 278
#define ID_ID 279
#define CADENA 280
#define CARACTER 281
#define TRUE 282
#define FALSE 283
#define DOSPUNTOS 284
#define ASIGNACION 285
#define OR 286
#define AND 287
#define IGUALACION 288
#define DIFERENTE 289
#define MAYOROIGUAL 290
#define MENOROIGUAL 291
#define MENOR 292
#define MAYOR 293
#define MAS 294
#define MENOS 295
#define POR 296
#define ENTRE 297
#define MODULO 298
#define NEGACION 299
#define ELSE2 300
#define PARENTESISDERECHO 301
#define PARENTESISIZQUIERDO 302
#define CORCHETEDERECHO 303
#define CORCHETEIZQUIERDO 304
#define LLAVEDERECHA 305
#define LLAVEIZQUIERDA 306
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    4,    0,    7,    3,    3,    1,    1,    1,    1,    1,
    1,    6,    6,    2,    2,    8,   11,    5,    5,    9,
    9,   12,   12,   13,   13,   10,   10,   10,   10,   10,
   10,   10,   10,   10,   10,   10,   10,   10,   17,   17,
   18,   18,   15,   15,   15,   19,   19,   16,   16,   16,
   16,   16,   16,   16,   16,   16,   16,   20,   20,   21,
   21,   14,   14,   14,   14,   14,   14,   14,   22,   22,
   22,   22,   22,   22,
};
short yylen[] = {                                         2,
    0,    3,    0,    5,    0,    1,    1,    1,    1,    1,
    4,    4,    2,    4,    0,    0,    0,   13,    0,    1,
    0,    5,    3,    3,    0,    2,    5,    7,    5,    7,
    9,    4,    3,    2,    3,    8,    2,    3,    5,    0,
    3,    0,    1,    1,    1,    4,    4,    3,    3,    3,
    3,    3,    1,    1,    1,    1,    4,    1,    0,    3,
    1,    3,    3,    2,    3,    3,    1,    1,    1,    1,
    1,    1,    1,    1,
};
short yydefred[] = {                                      1,
    0,    0,    6,    7,    8,    9,   10,    0,    3,    0,
    0,    0,    2,    0,    0,    0,    0,    0,   11,    0,
   13,    0,    0,    0,    0,    4,    0,    0,    0,   12,
    0,   14,    0,    0,    0,    0,    0,    0,    0,   23,
    0,    0,    0,    0,    0,   24,    0,    0,    0,    0,
    0,    0,    0,    0,    0,   45,    0,    0,    0,    0,
   22,    0,    0,    0,    0,    0,   34,    0,   55,   54,
   56,    0,    0,    0,   37,    0,    0,   17,    0,    0,
    0,    0,   67,   68,    0,    0,    0,    0,    0,    0,
    0,    0,   33,    0,    0,    0,    0,    0,    0,   38,
   35,    0,    0,    0,   46,   64,    0,    0,    0,    0,
   74,   73,   72,   71,   69,   70,    0,    0,    0,    0,
    0,    0,    0,    0,    0,   50,   51,   52,    0,   18,
   32,   47,   65,    0,   63,    0,    0,    0,    0,    0,
   57,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   30,    0,    0,    0,    0,    0,    0,    0,   36,    0,
    0,    0,   39,
};
short yydgoto[] = {                                       1,
    9,   21,   10,    2,   13,   17,   12,   14,   34,   79,
  102,   35,   40,   87,   59,   88,  149,  155,   60,  122,
  123,  117,
};
short yysindex[] = {                                      0,
    0,  213,    0,    0,    0,    0,    0, -304,    0,    0,
  213, -245,    0, -249, -274, -262, -253,  213,    0, -210,
    0,  213, -199, -188, -235,    0, -262, -219, -262,    0,
  213,    0, -171, -203, -166, -194, -195,  213, -187,    0,
  213, -135, -194,   17, -194,    0, -137, -128, -108,   17,
  -92,  -61,  -91,  -99,  -26,    0,   17, -127,  -63,  -81,
    0,  -26,  -74,  -74,   40,   17,    0, -277,    0,    0,
    0, -138,  -81,  -26,    0, -125,  -88,    0,   17,  -26,
  -26,   47,    0,    0,  -74,  -74, -133,  153,   -4,  -73,
 -184,  -26,    0,  -26,  -26,  -26,  -26,  -26,  168,    0,
    0,    0,  -82,  158,    0,    0,    8,  -74,  -74,   17,
    0,    0,    0,    0,    0,    0,  -26,   17,  -74,  -74,
   57,  -66,  -23,  -64,  -64,    0,    0,    0,  -53,    0,
    0,    0,    0,  -37,    0,  148,   57,  161,   16, -136,
    0,  -26,  -21,   17, -140,   17,   57,  -24,  -20,   17,
    0,  -75,   -9,  -17,  -41,   17,   17,   17,    0,  161,
  -27,   17,    0,
};
short yyrindex[] = {                                      0,
    0,    3,    0,    0,    0,    0,    0,    0,    0,   11,
  -19,    0,    0,    0,    0, -157,    0,    0,    0,    0,
    0,    1,    0,    0,    0,    0, -157,    0, -157,    0,
  -40,    0,    0,    0,   -3, -244,    0,    0,    0,    0,
   54,    0, -244,    0, -244,    0,   -1,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   14,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   75,    0,    0,    0,    0,    0, -224,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    4,    0,    0,    0,    0,    0,    0,    0,    0,
    0,   11,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
 -242,    0,   19,   93,  112,    0,    0,    0,    0,    0,
    0,    0,    0, -258,    0, -243, -246, -196,    0,    0,
    0,    0, -269,    0,    0,    0, -231,    0,   -5,  -42,
    0,    0,    0,    0,    0,    0,    0,    0,    0,  -39,
   -5, -254,    0,
};
short yygindex[] = {                                      0,
  124,  134,   85,    0,  199,    0,    0,    0,    0,  -44,
    0,    0,  132,  -56,    0,   23,    0,  160,  -48,    0,
    0,    0,
};
#define YYTABLESIZE 475
short yytable[] = {                                      58,
    5,   11,    5,   73,   62,   65,   73,   89,   40,   22,
   19,   23,   77,   73,   73,   73,   66,   18,   16,   27,
   25,   91,   61,   41,   92,   73,   62,   62,  106,  107,
   19,   73,   73,   60,   27,   40,   73,   73,   26,   66,
   66,   20,   62,   73,   26,   73,   73,   73,   73,   73,
   41,  134,  135,   26,   66,   25,   25,   27,   61,   73,
   73,   27,  139,  140,   27,  136,   29,   29,   73,   60,
   73,   73,   29,  138,   72,   28,   26,   76,  120,   47,
   26,   29,   31,   48,   82,   49,   50,   51,   52,   53,
   54,   55,   36,   73,   56,   15,   99,   37,   38,  150,
  138,  152,  103,  104,   29,   15,   26,   15,   29,   39,
   41,  160,  161,  162,  121,   43,  124,  125,  126,  127,
  128,   57,  151,   47,   93,   44,  146,   48,   45,   49,
   50,   51,   52,   53,   54,   55,   47,  100,   56,  137,
   48,   24,   49,   50,   51,   52,   53,   54,   55,  108,
  109,   56,  108,  109,   33,   94,   95,   96,   97,   98,
   30,   42,   32,   75,  147,   57,   62,  110,   94,   95,
   96,   97,   98,   63,   46,   47,   61,   78,   57,   48,
  131,   49,   50,   51,   52,   53,   54,   55,   47,   68,
   56,   69,   48,   64,   49,   50,   51,   52,   53,   54,
   55,   67,   68,   56,   69,   70,   71,   83,   84,   66,
   74,   94,   95,   96,   97,   98,  101,   57,   70,   71,
   28,   80,   81,   31,   85,  156,   28,   86,  119,   31,
   57,   96,   97,   98,  141,   28,   47,   68,   31,   69,
   48,  142,   49,   50,   51,   52,   53,   54,   55,  109,
  154,   56,  143,   70,   71,  148,  157,  154,   28,  153,
   21,   31,   28,  159,    5,   31,  158,    5,    5,    5,
    5,    5,    5,    5,    5,    5,    5,   16,   57,    5,
   47,  108,  109,   43,   48,    5,   49,   50,   51,   52,
   53,   54,   55,  108,  109,   56,  118,   20,   44,   42,
  130,  108,  109,   47,   59,    5,    5,   48,  133,   90,
   50,   51,   52,   53,   54,   55,  145,    5,   56,   58,
  163,    5,   57,    5,    5,    5,    5,    5,    5,    5,
    0,    0,    5,    0,    0,    0,    0,   53,    0,   53,
   94,   95,   96,   97,   98,   57,    0,    0,    0,  105,
   94,   95,   96,   97,   98,   48,    0,   48,    0,    5,
   53,   53,   53,   53,   53,   53,   53,   53,   53,   53,
   53,   53,   53,    0,   49,   53,   49,   53,   48,   48,
   48,   48,   48,   48,   48,   48,   48,   48,    0,    0,
    0,    0,    0,   48,    0,   48,    0,   49,   49,   49,
   49,   49,   49,   49,   49,   49,   49,    0,    0,    0,
    0,   47,   49,    0,   49,   48,  144,   49,   50,   51,
   52,   53,   54,   55,   47,    0,   56,    0,   48,    0,
   49,   50,   51,   52,   53,   54,   55,    0,    0,   56,
  111,  112,  113,  114,  115,  116,   94,   95,   96,   97,
   98,   94,   95,   96,   97,   98,    0,    0,    0,    0,
  132,   94,   95,   96,   97,   98,    0,    0,  129,    3,
    4,    5,    6,    7,    8,
};
short yycheck[] = {                                      44,
    0,  306,    0,   52,  263,   50,   55,   64,  278,  263,
    0,  265,   57,   62,   63,   64,  263,  267,  264,  263,
  265,   66,  265,  278,  302,   74,  304,  286,   85,   86,
  305,   80,   81,  265,  278,  305,   85,   86,  263,  286,
  287,  304,  301,   92,  269,   94,   95,   96,   97,   98,
  305,  108,  109,  278,  301,  266,  301,  301,  301,  108,
  109,  305,  119,  120,  264,  110,  263,  303,  117,  301,
  119,  120,  269,  118,   52,  264,  301,   55,  263,  264,
  305,  278,  302,  268,   62,  270,  271,  272,  273,  274,
  275,  276,  264,  142,  279,   11,   74,  301,  265,  144,
  145,  146,   80,   81,  301,  263,   22,  265,  305,  304,
  306,  156,  157,  158,   92,  303,   94,   95,   96,   97,
   98,  306,  263,  264,  263,   41,  263,  268,  264,  270,
  271,  272,  273,  274,  275,  276,  264,  263,  279,  117,
  268,   18,  270,  271,  272,  273,  274,  275,  276,  286,
  287,  279,  286,  287,   31,  294,  295,  296,  297,  298,
   27,   38,   29,  263,  142,  306,  304,  301,  294,  295,
  296,  297,  298,  302,   43,  264,   45,  305,  306,  268,
  263,  270,  271,  272,  273,  274,  275,  276,  264,  264,
  279,  266,  268,  302,  270,  271,  272,  273,  274,  275,
  276,  263,  264,  279,  266,  280,  281,  282,  283,  302,
  302,  294,  295,  296,  297,  298,  305,  306,  280,  281,
  263,  285,  304,  263,  299,  301,  269,  302,  302,  269,
  306,  296,  297,  298,  301,  278,  264,  264,  278,  266,
  268,  265,  270,  271,  272,  273,  274,  275,  276,  287,
  278,  279,  306,  280,  281,  277,  266,  278,  301,  284,
  301,  301,  305,  305,  264,  305,  284,  267,  268,  267,
  270,  271,  272,  273,  274,  275,  276,  267,  306,  279,
  264,  286,  287,  285,  268,  305,  270,  271,  272,  273,
  274,  275,  276,  286,  287,  279,  301,  301,  285,  305,
  102,  286,  287,  264,  301,  305,  306,  268,  301,  270,
  271,  272,  273,  274,  275,  276,  301,  264,  279,  301,
  161,  268,  306,  270,  271,  272,  273,  274,  275,  276,
   -1,   -1,  279,   -1,   -1,   -1,   -1,  263,   -1,  265,
  294,  295,  296,  297,  298,  306,   -1,   -1,   -1,  303,
  294,  295,  296,  297,  298,  263,   -1,  265,   -1,  306,
  286,  287,  288,  289,  290,  291,  292,  293,  294,  295,
  296,  297,  298,   -1,  263,  301,  265,  303,  286,  287,
  288,  289,  290,  291,  292,  293,  294,  295,   -1,   -1,
   -1,   -1,   -1,  301,   -1,  303,   -1,  286,  287,  288,
  289,  290,  291,  292,  293,  294,  295,   -1,   -1,   -1,
   -1,  264,  301,   -1,  303,  268,  269,  270,  271,  272,
  273,  274,  275,  276,  264,   -1,  279,   -1,  268,   -1,
  270,  271,  272,  273,  274,  275,  276,   -1,   -1,  279,
  288,  289,  290,  291,  292,  293,  294,  295,  296,  297,
  298,  294,  295,  296,  297,  298,   -1,   -1,   -1,   -1,
  303,  294,  295,  296,  297,  298,   -1,   -1,  301,  257,
  258,  259,  260,  261,  262,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 306
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"INT","FLOAT","DOUBLE","CHAR",
"VOID","STRUCT","PUNTOYCOMA","ID","COMA","NUMERO","FUNC","IF","ELSE","WHILE",
"DO","FOR","RETURN","SWITCH","BREAK","PRINT","CASE","DEFAULT","ID_ID","CADENA",
"CARACTER","TRUE","FALSE","DOSPUNTOS","ASIGNACION","OR","AND","IGUALACION",
"DIFERENTE","MAYOROIGUAL","MENOROIGUAL","MENOR","MAYOR","MAS","MENOS","POR",
"ENTRE","MODULO","NEGACION","ELSE2","PARENTESISDERECHO","PARENTESISIZQUIERDO",
"CORCHETEDERECHO","CORCHETEIZQUIERDO","LLAVEDERECHA","LLAVEIZQUIERDA",
};
char *yyrule[] = {
"$accept : programa",
"$$1 :",
"programa : $$1 declaraciones fun",
"$$2 :",
"declaraciones : tipo $$2 lista PUNTOYCOMA declaraciones",
"declaraciones :",
"tipo : INT",
"tipo : FLOAT",
"tipo : DOUBLE",
"tipo : CHAR",
"tipo : VOID",
"tipo : STRUCT LLAVEIZQUIERDA declaraciones LLAVEDERECHA",
"lista : lista COMA ID arreglo",
"lista : ID arreglo",
"arreglo : CORCHETEIZQUIERDO NUMERO CORCHETEDERECHO arreglo",
"arreglo :",
"$$3 :",
"$$4 :",
"fun : $$3 FUNC tipo ID PARENTESISIZQUIERDO arg PARENTESISDERECHO LLAVEIZQUIERDA declaraciones sent LLAVEDERECHA $$4 fun",
"fun :",
"arg : list_arg",
"arg :",
"list_arg : list_arg COMA tipo ID parte_arreglo",
"list_arg : tipo ID parte_arreglo",
"parte_arreglo : CORCHETEIZQUIERDO CORCHETEDERECHO parte_arreglo",
"parte_arreglo :",
"sent : sent sent",
"sent : IF PARENTESISIZQUIERDO cond PARENTESISDERECHO sent",
"sent : IF PARENTESISIZQUIERDO cond PARENTESISDERECHO sent ELSE sent",
"sent : WHILE PARENTESISIZQUIERDO cond PARENTESISDERECHO sent",
"sent : DO sent WHILE PARENTESISIZQUIERDO cond PARENTESISDERECHO PUNTOYCOMA",
"sent : FOR PARENTESISIZQUIERDO sent PUNTOYCOMA cond PUNTOYCOMA sent PARENTESISDERECHO sent",
"sent : par_iz ASIGNACION exp PUNTOYCOMA",
"sent : RETURN exp PUNTOYCOMA",
"sent : RETURN PUNTOYCOMA",
"sent : LLAVEIZQUIERDA sent LLAVEDERECHA",
"sent : SWITCH PARENTESISIZQUIERDO exp PARENTESISDERECHO LLAVEIZQUIERDA caso pred LLAVEDERECHA",
"sent : BREAK PUNTOYCOMA",
"sent : PRINT exp PUNTOYCOMA",
"caso : CASE DOSPUNTOS NUMERO sent pred",
"caso :",
"pred : DEFAULT DOSPUNTOS sent",
"pred :",
"par_iz : ID",
"par_iz : va",
"par_iz : ID_ID",
"va : ID CORCHETEIZQUIERDO exp CORCHETEDERECHO",
"va : va CORCHETEIZQUIERDO exp CORCHETEDERECHO",
"exp : exp MAS exp",
"exp : exp MENOS exp",
"exp : exp POR exp",
"exp : exp ENTRE exp",
"exp : exp MODULO exp",
"exp : va",
"exp : CADENA",
"exp : NUMERO",
"exp : CARACTER",
"exp : ID PARENTESISIZQUIERDO param PARENTESISDERECHO",
"param : list_param",
"param :",
"list_param : list_param COMA exp",
"list_param : exp",
"cond : cond OR cond",
"cond : cond AND cond",
"cond : NEGACION cond",
"cond : PARENTESISIZQUIERDO cond PARENTESISDERECHO",
"cond : exp rel exp",
"cond : TRUE",
"cond : FALSE",
"rel : MENOR",
"rel : MAYOR",
"rel : MENOROIGUAL",
"rel : MAYOROIGUAL",
"rel : DIFERENTE",
"rel : IGUALACION",
};
#endif
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#ifdef YYSTACKSIZE
#ifndef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#endif
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 251 "semantic.y"

void init(){
    cuentaTablasSimbolos = 0; 
    cuentaTablasTipos = 0;
    tablaSimbolos1 = (tablaSimbolos *)malloc(sizeof(tablaSimbolos));
    tablaSimbolos1->id = cuentaTablasSimbolos;
    tablaTipos1 = (tablaTipos *)malloc(sizeof(tablaTipos));
    tablaTipos1->id = cuentaTablasTipos;
    cuentaTablasSimbolos ++;
    cuentaTablasTipos ++;
    create_table(&tabla_de_simbolos);
    create_code(&codigo_intermedio);
    create_labels(&lfalses);    
    struct elemento *tmp = (struct elemento*)malloc(sizeof(struct elemento));
    tmp->tabla = &tablaSimbolos1;
    push(&pilaTablas1, tmp);
    struct elementoTipos *tmpTipos = (struct elementoTipos *)malloc(sizeof(struct elementoTipos));
    tmpTipos->tabla = &tablaTipos1;
    pushTipos(&pilaTipos1, tmpTipos);
}

void finish(){    
    print_code(&codigo_intermedio);    
}

exp suma(exp e1, exp e2){
    exp e;
    cuadrupla c;
    e.type = max(e1.type, e2.type);
    if( e.type==-1) yyerror("Error de tipos");
    else{
        char t[32];
        strcpy(t,newTemp());
        strcpy(e.dir, t);
        c.op = MA;
        strcpy(c.op1, ampliar(e1.dir, e1.type, e.type));
        strcpy(c.op2, ampliar(e2.dir, e2.type, e.type));
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
    }
    return e;    
}

exp resta(exp e1, exp e2){
    exp e;
    cuadrupla c;
    char t[32];
    e.type = max(e1.type, e2.type);
    
    if( e.type==-1) yyerror("Error de tipos");
    else{
        strcpy(t,newTemp());
        strcpy(e.dir, t);
        c.op = MEN;
        strcpy(c.op1, ampliar(e1.dir, e1.type, e.type));
        strcpy(c.op2, ampliar(e2.dir, e2.type, e.type));
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
    }
    return e;    
}

exp multiplicacion(exp e1, exp e2){
    exp e;
    cuadrupla c;
    e.type = max(e1.type, e2.type);
    if( e.type==-1) yyerror("Error de tipos");
    else{
        char t[32];
        strcpy(t,newTemp());
        strcpy(e.dir, t);
        c.op = ML;
        strcpy(c.op1, ampliar(e1.dir, e1.type, e.type));
        strcpy(c.op2, ampliar(e2.dir, e2.type, e.type));
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
    }
    return e;    
}

exp division(exp e1, exp e2){
    exp e;
    cuadrupla c;
    e.type = max(e1.type, e2.type);
    if( e.type==-1) yyerror("Error de tipos");
    else{
        char t[32];
        strcpy(t,newTemp());
        strcpy(e.dir, t);
        c.op = DV;
        strcpy(c.op1, ampliar(e1.dir, e1.type, e.type));
        strcpy(c.op2, ampliar(e2.dir, e2.type, e.type));
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
    }
    return e;    
}

exp asignacion(char *id, exp e){
    exp e1;
    int tipo = get_type(&tabla_de_simbolos, id);
    if( tipo != -1){        
        e1.type = e.type;
        strcpy(e1.dir, id);
        cuadrupla c;
        c.op = AS;
        strcpy(c.op1, reducir(e.dir, tipo, e.type));
        strcpy(c.op2, "");
        strcpy(c.res, id);
        insert_cuad(&codigo_intermedio, c);  
        
    }else{
        yyerror("El identificador no fue declarado\n");
    }
    return e1;
}


exp get_numero(numero n){
    exp e;
    e.type = n.type;
    strcpy(e.dir, n.val);
    return e;
}

exp identificador(char *id){
    exp e;
    if(search(&tabla_de_simbolos, id)!=-1){
        e.type = get_type(&tabla_de_simbolos, id);
        strcpy(e.dir, id);
    }else{
        yyerror("Error semantico: el identificador no existe");
    }
    return e;
}


int max(int t1, int t2){
    if( t1==t2) return t1;
    if( t1 ==0 && t2 == 1) return 1;
    if( t1 ==1 && t2 == 0) return 1;    
    if( t1 ==0 && t2 == 2) return 2;
    if( t1 ==2 && t2 == 0) return 2;
    if( t1 ==2 && t2 == 1) return 2;
    if( t1 ==1 && t2 == 2) return 2;
    else return -1;
}

char *ampliar(char *dir, int t1, int t2){
    cuadrupla c;
    char *t= (char*) malloc(32*sizeof(char));
    
    if( t1==t2) return dir;
    if( t1 ==0 && t2 == 1){
        c.op = EQ;
        strcpy(c.op1, "(float)");
        strcpy(c.op2, dir);
        strcpy(t, newTemp());
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
        return t;
    }        
    if( t1 ==0 && t2 == 2){
        c.op = EQ;
        strcpy(c.op1, "(double)");
        strcpy(c.op2, dir);
        strcpy(t, newTemp());
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
        return t;
    }        
    
    if( t1 ==1 && t2 == 2) {
        c.op = EQ;
        strcpy(c.op1, "(double)");
        strcpy(c.op2, dir);
        strcpy(t, newTemp());
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
        return t;
    }            
}


char *reducir(char *dir, int t1, int t2){
    cuadrupla c;
    char *t= (char*) malloc(32*sizeof(char));
    
    if( t1==t2) return dir;
    if( t1 ==0 && t2 == 1){
        c.op = EQ;
        strcpy(c.op1, "(int)");
        strcpy(c.op2, dir);
        strcpy(t, newTemp());
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
        printf("perdida de información se esta asignando un float a un int\n");
        return t;
    }        
    if( t1 ==0 && t2 == 2){
        c.op = EQ;
        strcpy(c.op1, "(int)");
        strcpy(c.op2, dir);
        strcpy(t, newTemp());
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
        printf("perdida de información se esta asignando un double a un int\n");
        return t;
    }        
    
    if( t1 ==1 && t2 == 2) {
        c.op = EQ;
        strcpy(c.op1, "(float)");
        strcpy(c.op2, dir);
        strcpy(t, newTemp());
        strcpy(c.res, t);
        insert_cuad(&codigo_intermedio, c);
        printf("perdida de información se esta asignando un double a un float\n");
        return t;
    }            
}

char* newTemp(){
    char *temporal= (char*) malloc(32*sizeof(char));
    strcpy(temporal , "t");
    char num[30];
    sprintf(num, "%d", temp);
    strcat(temporal, num);
    temp++;
    return temporal;
}

char* newLabel(){
    char *temporal= (char*) malloc(32*sizeof(char));
    strcpy(temporal , "L");
    char num[30];
    sprintf(num, "%d", label);
    strcat(temporal, num);
    label++;
    return temporal;
}


char* newIndex(){
    char *temporal= (char*) malloc(32*sizeof(char));
    strcpy(temporal , "I");
    char num[30];
    sprintf(num, "%d", indice);
    strcat(temporal, num);
    indice++;
    return temporal;
}

void yyerror2(char *c, char *c2){
    strcat(c, c2);
    yyerror(c);
}

void yyerror(char *s){
    printf("%s: en la línea %d\n",s, yylineno);
}

void errorID(char *id) {
    printf("\nError, se encontró un ID duplicado: %s\n\n",id);
}

void tablaNueva(){
    printf("hola");

}
#line 746 "y.tab.c"
#define YYABORT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, reading %d (%s)\n", yystate,
                    yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("yydebug: state %d, shifting to state %d (%s)\n",
                    yystate, yytable[yyn],yyrule[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: state %d, error recovery shifting\
 to state %d\n", *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: error recovery discarding state %d\n",
                            *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, error recovery discards token %d (%s)\n",
                    yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("yydebug: state %d, reducing by rule %d (%s)\n",
                yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 153 "semantic.y"
{init();}
break;
case 2:
#line 154 "semantic.y"
{
    print_table(&tabla_de_simbolos);
    imprimirTablaSimbolos(*(pilaTablas1->tabla));
    imprimirTablaTipos(tablaTipos1);
    finish();
            }
break;
case 3:
#line 161 "semantic.y"
{current_type = yyvsp[0].tipo.type; current_dim = yyvsp[0].tipo.dim;}
break;
case 6:
#line 164 "semantic.y"
{yyval.tipo.type = 0; yyval.tipo.dim = 4;insertarFilaTablaTipos(&(*(pilaTipos1->tabla)), 0, 4, -1);}
break;
case 7:
#line 165 "semantic.y"
{yyval.tipo.type =1; yyval.tipo.dim = 4; insertarFilaTablaTipos(&(*(pilaTipos1->tabla)), 1, 4, -1);}
break;
case 8:
#line 166 "semantic.y"
{yyval.tipo.type= 2; yyval.tipo.dim = 8; insertarFilaTablaTipos(&(*(pilaTipos1->tabla)), 2, 8, -1);}
break;
case 9:
#line 167 "semantic.y"
{yyval.tipo.type =3; yyval.tipo.dim = 1; insertarFilaTablaTipos(&(*(pilaTipos1->tabla)), 3, 1, -1);}
break;
case 10:
#line 168 "semantic.y"
{yyval.tipo.type =4; yyval.tipo.dim = 0; insertarFilaTablaTipos(&(*(pilaTipos1->tabla)), 4, 0, -1);}
break;
case 11:
#line 169 "semantic.y"
{yyval.tipo.type =5; yyval.tipo.dim = 0;}
break;
case 12:
#line 172 "semantic.y"
{ 
            sym s;
            strcpy(s.id, yyvsp[-1].id);
            s.type = current_type;
            s.dir = dir;
            insertarFila(&(*(pilaTablas1->tabla)), yyvsp[-1].id, current_type, dir, VAR, NULL);
            dir+= current_dim;
            insert(&tabla_de_simbolos, s);
        
        }
break;
case 13:
#line 182 "semantic.y"
{
            sym s;
            strcpy(s.id, yyvsp[-1].id);
            s.type = current_type;
            s.dir = dir;
            insert(&tabla_de_simbolos, s);
            insertarFila(&(*(pilaTablas1->tabla)), yyvsp[-1].id, current_type, dir, VAR, NULL);
            dir+= current_dim;
        }
break;
case 14:
#line 192 "semantic.y"
{
    yyvsp[0].base = yyval.base;
    current_type = insertarFilaTablaTipos(&(*(pilaTipos1->tabla)), 10, (int)strtol(yyvsp[-2].num.val, (char **)NULL, 10), current_type);
}
break;
case 16:
#line 197 "semantic.y"
{
    tablaSimbolos *tmp = (tablaSimbolos *)malloc(sizeof(tablaSimbolos));
    struct elemento *tmp1 = (struct elemento *)malloc(sizeof(struct elemento));
    tmp1->tabla = &tmp;
    (*(tmp1->tabla))->id = cuentaTablasSimbolos;
    cuentaTablasSimbolos++;
    push(&pilaTablas1, tmp1);
}
break;
case 17:
#line 205 "semantic.y"
{
    imprimirTablaSimbolos(*(pilaTablas1->tabla));
}
break;
case 18:
#line 208 "semantic.y"
{
    if (existe(tablaSimbolos1, yyvsp[-9].id) != 0) {
        
        errorID(yyvsp[-9].id);
        pop(&pilaTablas1);
    }
    else {
        insertarFila(&tablaSimbolos1, yyvsp[-9].id, current_type, -1, FUNCVAR, NULL);
        pop(&pilaTablas1);
    }
}
break;
#line 990 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("yydebug: after reduction, shifting from state 0 to\
 state %d\n", YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("yydebug: state %d, reading %d (%s)\n",
                        YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("yydebug: after reduction, shifting from state %d \
to state %d\n", *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
