#ifndef PILA_TABLAS_TIPOS
#define PILA_TABLAS_TIPOS

#include "TablaTipos.h"

struct elementoTipos{
    struct elementoTipos *siguiente;
    tablaTipos **tabla;
};

void pushTipos(struct elementoTipos **cabeza, struct elementoTipos *nuevo);
struct elementoTipos *popTipos(struct elementoTipos **cabeza);

#endif