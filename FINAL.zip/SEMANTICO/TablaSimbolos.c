
/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
    30/11/18*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "TablaSimbolos.h"
#define VAR 1
#define FUNC 2

//Funcion utilizada para imprimir el contenido de la tabla
void imprimirTablaSimbolos(tablaSimbolos *tabla){
    int i;
    int cuenta = tabla->cuenta;
    printf("Tabla Simbolos\n");
    printf("id tabla %d\n", tabla->id);
    printf("position\tid\t\ttipo\tdir\tvar\n");
    for(i = 0; i < cuenta; i++)
    {
        int j = tabla->posiciones[i];
        printf("%d\t\t", tabla->filas[j].position);
        printf("%s\t\t", tabla->filas[j].id);
        printf("%d\t", tabla->filas[j].tipo);
        printf("%d\t", tabla->filas[j].dir);
        printf("%d\t", tabla->filas[j].var);
        printf("argumentos ");
        imprimirLista(tabla->filas[j].args);
        printf("\n");
    }
    printf("\n");
}

//Obtiene la llave del algoritmo hash
int getKey(char* id){
    int longitud = strlen(id);
    int key = 0;
    int i;
    for(i = 0; i < longitud; i++){
        key = (int)id[i] + key;
    }
    return key;
}

//Inserta una nueva fila en la tabla 
int insertarFila(tablaSimbolos **tabla,char* id, int tipo, int dir, int var, NODO *args){
    int numeroPrimo = 467;
    int hash = getKey(id) % numeroPrimo;
    //printf("posicion en la tabla %d ocupado %d\n", hash, (*tabla)->filas[hash].ocupado);
    if (!((*tabla)->filas[hash].ocupado)){
        insertarPosiciones(&((*tabla)->posiciones), hash, &((*tabla)->cuenta));
        (*tabla)->filas[hash].position = hash;
        (*tabla)->filas[hash].id = (char *)malloc(sizeof(char) * strlen(id));
        strcpy((*tabla)->filas[hash].id, id);
        (*tabla)->filas[hash].tipo = tipo;
        (*tabla)->filas[hash].var = var;
        (*tabla)->filas[hash].dir = dir;
        (*tabla)->filas[hash].ocupado = 1;
        (*tabla)->filas[hash].args = args;
    }else {
        printf("posicion ya ocupada %s\n",id);
    }
    return hash;
}

//Verifica si un dato ya existe en la tabla
int existe(tablaSimbolos *tabla, char *id){
    if (!(tabla->filas[getKey(id)].ocupado)) {
        return 0;
    }
    return 1;
}
