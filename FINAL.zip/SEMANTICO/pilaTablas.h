#ifndef PILA_TABLAS
#define PILA_TABLAS

#include "TablaSimbolos.h"

struct elemento {
    struct elemento *siguiente;
    tablaSimbolos **tabla;
};

void push(struct elemento **cabeza, struct elemento *nuevo);
struct elemento *pop(struct elemento **cabeza);
void imprimirPila(struct elemento *cabeza);
#endif
