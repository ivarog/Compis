#define INT 257
#define FLOAT 258
#define DOUBLE 259
#define CHAR 260
#define VOID 261
#define STRUCT 262
#define PUNTOYCOMA 263
#define ID 264
#define COMA 265
#define NUMERO 266
#define FUNC 267
#define IF 268
#define ELSE 269
#define WHILE 270
#define DO 271
#define FOR 272
#define RETURN 273
#define SWITCH 274
#define BREAK 275
#define PRINT 276
#define CASE 277
#define DEFAULT 278
#define ID_ID 279
#define CADENA 280
#define CARACTER 281
#define TRUE 282
#define FALSE 283
#define DOSPUNTOS 284
#define ASIGNACION 285
#define OR 286
#define AND 287
#define IGUALACION 288
#define DIFERENTE 289
#define MAYOROIGUAL 290
#define MENOROIGUAL 291
#define MENOR 292
#define MAYOR 293
#define MAS 294
#define MENOS 295
#define POR 296
#define ENTRE 297
#define MODULO 298
#define NEGACION 299
#define ELSE2 300
#define PARENTESISDERECHO 301
#define PARENTESISIZQUIERDO 302
#define CORCHETEDERECHO 303
#define CORCHETEIZQUIERDO 304
#define LLAVEDERECHA 305
#define LLAVEIZQUIERDA 306
typedef union{
    numero num;    
    char id[32];
    int base;
    exp expresion;
    type tipo;
    struct{
	labels falses;
	labels trues;
    }booleanos;
    labels siguientes;
    struct{
        labels siguientes;
        bool ifelse;
    }siguientesp;
    int rel;
} YYSTYPE;
extern YYSTYPE yylval;
