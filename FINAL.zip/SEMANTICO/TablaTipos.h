#ifndef TABLA_TIPOS
#define TABLA_TIPOS

#include "listaArgs.h"

typedef struct nodoTablaTipos {
    long position;
    int tipo;
    int tam;
    int tipoBase;
    struct nodoTablaTipos *siguiente;
    struct nodoTablaTipos *anterior;
    int ocupado;
} NODOTABLA;

typedef struct TablaTipos {
    int cuenta;
    int *posiciones;
    int id;
    NODOTABLA *nodos[263];
} tablaTipos;


NODOTABLA *CrearNodoTablaTipos(long hash, int tipo, int tamano, int tipoBase);
int InsertarInicioTablaTipos(NODOTABLA **cabeza, long hash, int tipo, int tamano, int tipoBase);
int InsertarFinalTablaTipos(NODOTABLA **cabeza, long hash, int tipo, int tamano, int tipoBase);
void imprimirFilaTabla(NODOTABLA *cabeza);
void imprimirTablaTipos(tablaTipos *tabla);
long getKeyTablaTipos(int tipo, int tam, int tipoBase);
int iguales(NODOTABLA* fila,int tipo, int tam, int tipoBase);
int insertarFilaTablaTipos(tablaTipos **tabla, int tipo, int tam, int tipoBase);

#endif
