/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
	26 noviembre 2018*/

#include <stdio.h>
#include<string.h>
#include "tokens.h"
extern int yylex();
extern FILE *yyout;
extern FILE *yyin;
extern char *yytext;
extern int yylineno;
int token;

/*Función principal se encarga de leer el archivo de entrada y manejar los tokens dentro de otros
archivos donde se guardan las clases léxicas y los errores léxicos*/
int main(int argc, char const *argv[])
{
    FILE *f,*s,*c;

    if(argc<2) return -1;
    f=fopen(argv[1],"r");
    s=fopen("errores_lexicos.txt", "w");
	c=fopen("clases.txt", "w");
    if(!f || !s || !c) return -1;
    yyin=f;
    yyout=s;

    fputs("Errores Léxicos   ", yyout);	

    int cont_col=0; //Contador de columnas
    token=yylex();
    
    while(token != EOF)
    {
        //Advertencia de errores
        if(token == -2){
			fputs("\n\nLinea   ", yyout);
			fprintf(yyout, "%d", yylineno);
			fputs("  Columna  ", yyout);
			fprintf(yyout, "%d", cont_col);			
			fputs("  Caracter ", yyout);
			fputs(yytext, yyout);
			printf("Linea %d Columna %d Caracter %s\n",yylineno,cont_col,yytext);
        }else if(token == 80){
			//si encuentro un salto de linea
			//reinicio la cuenta de la columna del archivo
			cont_col = 0;
		}else {
            //Guarda dentro de c todas las clases y valores encontradas en el archivo
			fputs( "Clase ",c);
			fprintf(c, "%d", token);
			fputs(" Valor ", c);
			fputs( yytext, c);
			fputc('\n', c);
		}
		//aumenta el valor de la columna
		cont_col = strlen(yytext) + cont_col;
		token = yylex();
    }
    fclose(f);
    fclose(yyout);
    return 0;
}
