/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    include = 258,
    INT = 259,
    FLOAT = 260,
    DOUBLE = 261,
    CHAR = 262,
    VOID = 263,
    STRUCT = 264,
    PUNTOYCOMA = 265,
    ID = 266,
    COMA = 267,
    NUMERO = 268,
    FUNC = 269,
    IF = 270,
    ELSE = 271,
    WHILE = 272,
    DO = 273,
    FOR = 274,
    RETURN = 275,
    SWITCH = 276,
    BREAK = 277,
    PRINT = 278,
    CASE = 279,
    DEFAULT = 280,
    ID_ID = 281,
    CADENA = 282,
    CARACTER = 283,
    TRUE = 284,
    FALSE = 285,
    DOSPUNTOS = 286,
    ASIGNACION = 287,
    OR = 288,
    AND = 289,
    IGUALACION = 290,
    DIFERENTE = 291,
    MAYOROIGUAL = 292,
    MENOROIGUAL = 293,
    MENOR = 294,
    MAYOR = 295,
    MAS = 296,
    MENOS = 297,
    POR = 298,
    ENTRE = 299,
    MODULO = 300,
    NEGACION = 301,
    ELSE2 = 302,
    PARENTESISDERECHO = 303,
    PARENTESISIZQUIERDO = 304,
    CORCHETEDERECHO = 305,
    CORCHETEIZQUIERDO = 306,
    LLAVEDERECHA = 307,
    LLAVEIZQUIERDA = 308
  };
#endif
/* Tokens.  */
#define include 258
#define INT 259
#define FLOAT 260
#define DOUBLE 261
#define CHAR 262
#define VOID 263
#define STRUCT 264
#define PUNTOYCOMA 265
#define ID 266
#define COMA 267
#define NUMERO 268
#define FUNC 269
#define IF 270
#define ELSE 271
#define WHILE 272
#define DO 273
#define FOR 274
#define RETURN 275
#define SWITCH 276
#define BREAK 277
#define PRINT 278
#define CASE 279
#define DEFAULT 280
#define ID_ID 281
#define CADENA 282
#define CARACTER 283
#define TRUE 284
#define FALSE 285
#define DOSPUNTOS 286
#define ASIGNACION 287
#define OR 288
#define AND 289
#define IGUALACION 290
#define DIFERENTE 291
#define MAYOROIGUAL 292
#define MENOROIGUAL 293
#define MENOR 294
#define MAYOR 295
#define MAS 296
#define MENOS 297
#define POR 298
#define ENTRE 299
#define MODULO 300
#define NEGACION 301
#define ELSE2 302
#define PARENTESISDERECHO 303
#define PARENTESISIZQUIERDO 304
#define CORCHETEDERECHO 305
#define CORCHETEIZQUIERDO 306
#define LLAVEDERECHA 307
#define LLAVEIZQUIERDA 308

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
