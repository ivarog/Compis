/* 	Aco Guerrero Iván Rogelio
	Hernández Arrieta Carlos Alberto
	García Fernández Jesúsu Alejandro
    */
#include <stdio.h>
#include<string.h>
extern int yyparse();
extern FILE *yyout;
extern FILE *yyin;

/*Función principal, se encarga de leer el archivo de entrada y llamar a yyparse*/
int main(int argc, char const *argv[])
{
    FILE *f;

    if(argc<2) return -1;
    f=fopen(argv[1],"r");
    yyin=f;
	yyparse();
    fclose(f);
    return 0;
}
